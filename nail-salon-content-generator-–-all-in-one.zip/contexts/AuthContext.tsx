
import React, { createContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { User, AuthContextType, StoredUser, ToastType } from '../types';
import { UserService } from '../services/userService';
import { WEBHOOK_URL } from '../constants';
import { useToast } from '../hooks/useToast';

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { addToast } = useToast();

  const verifySession = useCallback(() => {
    setIsLoading(true);
    const sessionUser = UserService.getSession();
    if (sessionUser) {
      setCurrentUser(sessionUser);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    verifySession();
  }, [verifySession]);

  const login = useCallback(async (emailOrPhone: string, passwordAttempt: string): Promise<boolean> => {
    setIsLoading(true);
    const user = UserService.authenticateUser(emailOrPhone, passwordAttempt);
    if (user) {
      setCurrentUser(user);
      UserService.saveSession(user);
      addToast('Login successful!', ToastType.SUCCESS);
      setIsLoading(false);
      return true;
    }
    addToast('Invalid credentials. Please try again.', ToastType.ERROR);
    setIsLoading(false);
    return false;
  }, [addToast]);

  const signup = useCallback(async (email: string, phone: string, passwordPlain: string): Promise<boolean> => {
    setIsLoading(true);
    if (!email || !phone || !passwordPlain) {
      addToast('All fields are required for signup.', ToastType.ERROR);
      setIsLoading(false);
      return false;
    }
    if (passwordPlain.length < 6) {
        addToast('Password must be at least 6 characters long.', ToastType.ERROR);
        setIsLoading(false);
        return false;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        addToast('Invalid email format.', ToastType.ERROR);
        setIsLoading(false);
        return false;
    }
    // Basic phone validation (can be improved)
    const phoneRegex = /^\+?[0-9\s-()]{7,20}$/;
     if (!phoneRegex.test(phone)) {
        addToast('Invalid phone number format.', ToastType.ERROR);
        setIsLoading(false);
        return false;
    }


    const existingUser = UserService.findUserByEmailOrPhone(email, phone);
    if (existingUser) {
      addToast('User with this email or phone already exists.', ToastType.ERROR);
      setIsLoading(false);
      return false;
    }

    const newUser = UserService.createUser(email, phone, passwordPlain);
    if (newUser) {
      setCurrentUser(newUser);
      UserService.saveSession(newUser);
      
      // Send info to webhook
      try {
        await fetch(WEBHOOK_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: newUser.email, phone: newUser.phone }),
        });
      } catch (error) {
        console.error('Failed to send data to webhook:', error);
        // Optionally notify user or log, but don't block signup
      }
      
      addToast('Signup successful! Welcome.', ToastType.SUCCESS);
      setIsLoading(false);
      return true;
    }
    addToast('Signup failed. Please try again.', ToastType.ERROR);
    setIsLoading(false);
    return false;
  }, [addToast]);

  const logout = useCallback(() => {
    setIsLoading(true);
    UserService.clearSession();
    setCurrentUser(null);
    addToast('You have been logged out.', ToastType.INFO);
    setIsLoading(false);
  }, [addToast]);

  return (
    <AuthContext.Provider value={{ currentUser, isLoading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
