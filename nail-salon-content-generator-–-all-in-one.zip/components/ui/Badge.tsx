
import React from 'react';

interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'secondary' | 'destructive' | 'outline';
  children: React.ReactNode;
}

export const Badge: React.FC<BadgeProps> = ({ className, variant = 'default', children, ...props }) => {
  const baseStyles = "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2";
  
  const variantStyles = {
    default: "border-transparent bg-pink-600 text-white hover:bg-pink-600/80",
    secondary: "border-transparent bg-gray-200 text-gray-700 hover:bg-gray-200/80",
    destructive: "border-transparent bg-red-500 text-white hover:bg-red-500/80",
    outline: "text-foreground border-pink-500",
  };

  return (
    <div className={`${baseStyles} ${variantStyles[variant]} ${className || ''}`} {...props}>
      {children}
    </div>
  );
};
