
import React from 'react';
import { IconLoader2 } from '../icons'; // Assuming icons.tsx is in ../icons

interface SpinnerProps {
  size?: 'small' | 'medium' | 'large';
  className?: string;
}

export const Spinner: React.FC<SpinnerProps> = ({ size = 'medium', className }) => {
  const sizeClasses = {
    small: 'w-4 h-4',
    medium: 'w-6 h-6',
    large: 'w-10 h-10',
  };

  return (
    <IconLoader2 className={`animate-spin text-pink-600 ${sizeClasses[size]} ${className || ''}`} />
  );
};
