
import React from 'react';
import { APP_NAME } from '../constants';

const AppFooter: React.FC = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="bg-gray-800 text-white text-center p-4 shadow-inner">
      <p>&copy; {currentYear} {APP_NAME}. All rights reserved.</p>
    </footer>
  );
};

export default AppFooter;
