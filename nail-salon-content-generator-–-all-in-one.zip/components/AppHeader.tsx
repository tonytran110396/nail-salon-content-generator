
import React from 'react';
import { useAuth } from '../hooks/useAuth';
import { Button } from './ui/Button';
import { IconLogOut } from './icons';
import { APP_LOGO_TEXT } from '../constants';

const AppHeader: React.FC = () => {
  const { currentUser, logout } = useAuth();

  return (
    <header className="bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <img src="/public/logo.png" alt="App Logo" className="w-8 h-8 mr-3" aria-hidden="true" />
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight">{APP_LOGO_TEXT}</h1>
        </div>
        {currentUser && (
          <div className="flex items-center space-x-4">
            <span className="text-sm hidden sm:inline">{currentUser.email}</span>
            <Button
              variant="outline"
              size="sm"
              onClick={logout}
              className="bg-white text-pink-600 hover:bg-pink-100 border-pink-600 hover:text-pink-700"
            >
              <IconLogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        )}
      </div>
    </header>
  );
};

export default AppHeader;