
import React from 'react';
import { Button } from './ui/Button';
import { IconTrendingUp, IconShoppingCart, IconMegaphone, IconLaptop, IconGift, IconPhone } from './icons';
import { PROMOTIONAL_BANNER_ITEMS, CALL_TO_ACTION_MAIN_BANNER } from '../constants';

const iconMap: { [key: string]: React.FC<React.SVGProps<SVGSVGElement>> } = {
  TrendingUp: IconTrendingUp,
  ShoppingCart: IconShoppingCart,
  Megaphone: IconMegaphone,
  Laptop: IconLaptop,
  Gift: IconGift,
  Phone: IconPhone,
};

const PromotionalBanner: React.FC = () => {
  return (
    <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-8 my-8 rounded-lg shadow-xl">
      <div className="grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h2 className="text-3xl font-bold mb-6">Đừng Bỏ Lỡ Ưu Đãi Đặc Biệt!</h2>
          <ul className="space-y-3 mb-6">
            {PROMOTIONAL_BANNER_ITEMS.map((item, index) => {
              const IconComponent = iconMap[item.icon];
              return (
                <li key={index} className="flex items-center text-lg">
                  {IconComponent && <IconComponent className="w-6 h-6 mr-3 text-yellow-300" />}
                  {item.text}
                </li>
              );
            })}
          </ul>
        </div>
        <div className="flex flex-col items-center justify-center text-center">
            <IconPhone className="w-16 h-16 mb-4 text-yellow-300 animate-pulse" />
            <p className="text-xl font-semibold mb-2">Ready to Boost Your Salon?</p>
             <Button
                size="lg"
                variant="default"
                className="bg-yellow-400 text-purple-700 hover:bg-yellow-300 font-bold shadow-lg transform hover:scale-105 transition-transform"
                onClick={() => window.open('tel:8888595888', '_self')}
              >
                {CALL_TO_ACTION_MAIN_BANNER}
              </Button>
              <p className="mt-3 text-sm text-purple-200">Gọi ngay để nhận tư vấn miễn phí!</p>
        </div>
      </div>
    </div>
  );
};

export default PromotionalBanner;
