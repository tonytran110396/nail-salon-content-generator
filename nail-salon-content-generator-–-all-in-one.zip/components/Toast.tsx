
import React, { useEffect, useState } from 'react';
import { useToast } from '../hooks/useToast';
import { ToastMessage, ToastType } from '../types';
import { IconCheckCircle, IconAlertTriangle, IconInfo, IconX } from './icons';

const ToastIcons: Record<ToastType, React.FC<React.SVGProps<SVGSVGElement>>> = {
  [ToastType.SUCCESS]: IconCheckCircle,
  [ToastType.ERROR]: IconAlertTriangle,
  [ToastType.INFO]: IconInfo,
  [ToastType.WARNING]: IconAlertTriangle,
};

const ToastThemeColors: Record<ToastType, { bg: string; text: string; icon: string }> = {
  [ToastType.SUCCESS]: { bg: 'bg-green-500', text: 'text-white', icon: 'text-white' },
  [ToastType.ERROR]: { bg: 'bg-red-500', text: 'text-white', icon: 'text-white' },
  [ToastType.INFO]: { bg: 'bg-blue-500', text: 'text-white', icon: 'text-white' },
  [ToastType.WARNING]: { bg: 'bg-yellow-500', text: 'text-black', icon: 'text-black' },
};

interface ToastProps {
  toast: ToastMessage;
  onDismiss: (id: string) => void;
}

const Toast: React.FC<ToastProps> = ({ toast, onDismiss }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss(toast.id);
    }, 5000); // Auto-dismiss after 5 seconds

    return () => {
      clearTimeout(timer);
    };
  }, [toast.id, onDismiss]);

  const IconComponent = ToastIcons[toast.type];
  const colors = ToastThemeColors[toast.type];

  return (
    <div
      className={`max-w-sm w-full ${colors.bg} shadow-lg rounded-lg pointer-events-auto ring-1 ring-black ring-opacity-5 overflow-hidden my-2`}
    >
      <div className="p-4">
        <div className="flex items-start">
          <div className="flex-shrink-0">
            <IconComponent className={`h-6 w-6 ${colors.icon}`} aria-hidden="true" />
          </div>
          <div className="ml-3 w-0 flex-1 pt-0.5">
            <p className={`text-sm font-medium ${colors.text}`}>{toast.message}</p>
          </div>
          <div className="ml-4 flex-shrink-0 flex">
            <button
              onClick={() => onDismiss(toast.id)}
              className={`inline-flex rounded-md p-1 ${colors.text} hover:opacity-75 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500`}
            >
              <span className="sr-only">Close</span>
              <IconX className="h-5 w-5" aria-hidden="true" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};


const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useToast();

  if (!toasts.length) {
    return null;
  }

  return (
    <div
      aria-live="assertive"
      className="fixed inset-0 flex flex-col items-end px-4 py-6 pointer-events-none sm:p-6 sm:items-end z-50 space-y-2"
    >
      {toasts.map((toast) => (
        <Toast key={toast.id} toast={toast} onDismiss={removeToast} />
      ))}
    </div>
  );
};

export default ToastContainer;
