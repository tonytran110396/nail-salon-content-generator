
import { User, StoredUser } from '../types';
import { USERS_STORAGE_KEY, SESSION_STORAGE_KEY } from '../constants';

// Basic "encryption" - Base64 for demo purposes ONLY. NOT SECURE.
const encodePassword = (password: string): string => btoa(password);
const verifyPassword = (passwordAttempt: string, hash: string): boolean => {
  try {
    return btoa(passwordAttempt) === hash;
  } catch (e) { // handles invalid char in password for btoa
    return false;
  }
}


export const UserService = {
  getStoredUsers: (): StoredUser[] => {
    const usersJson = localStorage.getItem(USERS_STORAGE_KEY);
    return usersJson ? JSON.parse(usersJson) : [];
  },

  saveStoredUsers: (users: StoredUser[]): void => {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  },

  findUserByEmailOrPhone: (email: string, phone: string): StoredUser | undefined => {
    const users = UserService.getStoredUsers();
    return users.find(u => u.email === email || u.phone === phone);
  },
  
  findUserById: (id: string): StoredUser | undefined => {
    const users = UserService.getStoredUsers();
    return users.find(u => u.id === id);
  },

  createUser: (email: string, phone: string, passwordPlain: string): User | null => {
    if (UserService.findUserByEmailOrPhone(email, phone)) {
      console.error("User already exists with this email or phone.");
      return null; // Should be handled by caller
    }
    const users = UserService.getStoredUsers();
    const newUser: StoredUser = {
      id: Date.now().toString(), // Simple unique ID
      email,
      phone,
      passwordHash: encodePassword(passwordPlain),
    };
    users.push(newUser);
    UserService.saveStoredUsers(users);
    const { passwordHash, ...userToReturn } = newUser;
    return userToReturn;
  },

  authenticateUser: (emailOrPhone: string, passwordAttempt: string): User | null => {
    const users = UserService.getStoredUsers();
    const user = users.find(u => 
      (u.email === emailOrPhone || u.phone === emailOrPhone) 
    );

    if (user && verifyPassword(passwordAttempt, user.passwordHash)) {
      const { passwordHash, ...userToReturn } = user;
      return userToReturn;
    }
    return null;
  },

  saveSession: (user: User): void => {
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(user));
  },

  getSession: (): User | null => {
    const sessionJson = localStorage.getItem(SESSION_STORAGE_KEY);
    if (sessionJson) {
      try {
        const user = JSON.parse(sessionJson) as User;
        // Verify user still exists in main storage, in case of manual localStorage tampering
        if (UserService.findUserById(user.id)) {
            return user;
        } else {
            UserService.clearSession(); // Clean up invalid session
            return null;
        }
      } catch (e) {
        console.error("Error parsing session JSON:", e);
        UserService.clearSession();
        return null;
      }
    }
    return null;
  },

  clearSession: (): void => {
    localStorage.removeItem(SESSION_STORAGE_KEY);
  },
};
