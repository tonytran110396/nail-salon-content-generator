
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ContentFormData, GeneratedContent, ContentStyle } from '../types';
import { GEMINI_TEXT_MODEL, GEMINI_IMAGE_MODEL } from '../constants';

const getApiKey = (): string => {
  // Ensure process and process.env exist, as they might not in all browser environments
  // without a build process setting them up. The index.html provides a shim for local dev.
  if (typeof process !== 'undefined' && process.env && process.env.API_KEY) {
    if (process.env.API_KEY === "YOUR_GEMINI_API_KEY_HERE") {
        console.warn("Using placeholder API Key. Please replace in index.html or set process.env.API_KEY.");
        // throw new Error("API Key is placeholder. Please replace in index.html or environment variable.");
    }
    return process.env.API_KEY;
  }
  // Fallback or error if not found - this simple app relies on the index.html shim or actual env var
  console.error("API_KEY not found in process.env. Ensure it's set.");
  throw new Error("API_KEY not found. Please set it in index.html for local testing or as an environment variable.");
};


// Initialize the GoogleGenAI client
// This might throw if API_KEY is not available.
let ai: GoogleGenAI;
try {
    ai = new GoogleGenAI({ apiKey: getApiKey() });
} catch (e) {
    console.error("Failed to initialize GoogleGenAI:", e);
    // You might want to display an error to the user or disable AI features
    // For now, if this fails, subsequent calls will also fail.
}


const constructPromptForTextModel = (data: ContentFormData): string => {
  const effectiveContentStyle = data.contentStyleConcept === ContentStyle.OTHER
    ? data.customContentStyleConcept
    : data.contentStyleConcept;

  return `
You are a highly creative and professional Content Marketing Expert specializing in the nail salon industry.
Your mission is to generate compelling social media content based on the following details.
The output MUST be a VALID JSON object with three keys: "caption", "hashtags", and "imagePrompt".

Nail Salon & Post Details:
- Post Purpose: ${data.postPurpose}
- Main Topic/Keywords: ${data.topicKeywords}
- Target Customer Persona: ${data.customerPersona || 'General audience interested in nail art, beauty, and self-care'}
- Nail Salon Brand Name: ${data.brandName}
- Product/Service to Highlight: ${data.productService}
- Specific Industry Niche (if any): ${data.industry || 'Nail Care & Beauty'}
- Desired Content Style/Concept: ${effectiveContentStyle}
- Special Offer/Promotion (if any): ${data.specialOffer || 'N/A'}
- Clear Call To Action: ${data.callToActionText}
- Salon Address (optional, for local context): ${data.address || 'N/A'}
- Salon Phone Number (optional, for direct contact): ${data.phoneNumber || 'N/A'}
- Salon Website Link (optional, for more info): ${data.websiteLink || 'N/A'}

Detailed Instructions for each JSON key:

1.  "caption":
    *   Craft an engaging caption, approximately 50-100 words long.
    *   Language: English.
    *   Incorporate natural line breaks (use \\n) for optimal readability on social media platforms.
    *   Maintain a tone that is: Professional, inviting, and perfectly tailored to the nail salon's audience and brand voice.
    *   Seamlessly integrate: The salon's brand name ("${data.brandName}"), the specific product/service ("${data.productService}"), any special offer ("${data.specialOffer || 'No special offer currently'}"), and a clear call to action ("${data.callToActionText}").
    *   Make it sound exciting and appealing!

2.  "hashtags":
    *   Provide a string containing 3-5 relevant, and ideally trending, hashtags.
    *   Hashtags should be space-separated (e.g., "#NailArt #ManicureMonday #${data.brandName.replace(/\s+/g, '')} #NewNails").
    *   Include a mix of general nail-related tags, service-specific tags, and a brand tag.

3.  "imagePrompt":
    *   As a visionary Nail Design Art Director, create a detailed and versatile prompt for an AI image generator.
    *   The image MUST be photorealistic and depict a professional, high-quality nail design.
    *   Crucially, the image itself should NOT contain any embedded text, words, or letters.
    *   The prompt should be directly inspired by the "Main Topic/Keywords" ("${data.topicKeywords}") and "Product/Service to Highlight" ("${data.productService}").
    *   Emphasize: Ultra-realism, natural aesthetics, intricate details, and a sophisticated look, as if it's a high-resolution photograph of an actual nail design.
    *   Consider elements like: Nail shape (e.g., almond, stiletto, square), color palette (e.g., vibrant, pastel, monochrome), design complexity (e.g., minimalist, intricate patterns, 3D embellishments), finish (e.g., glossy, matte), and overall mood (e.g., elegant, playful, edgy).
    *   Example snippet for inspiration (adapt heavily based on inputs): "Photorealistic extreme close-up of impeccably manicured [nail shape, e.g., almond-shaped] nails, showcasing [specific design details based on keywords/product, e.g., delicate cherry blossom art with subtle gold flakes]. Dominant colors: [e.g., soft pinks and whites]. Finish: [e.g., high-gloss top coat]. Lighting: [e.g., soft, diffused studio lighting enhancing texture and depth]. Image style: [e.g., luxury fashion editorial, natural daylight shot]. Focus sharply on the nail artistry and realistic texture."
    *   The prompt must be descriptive enough for an AI to generate a stunning, unique, and relevant image.

Output MUST be in this strict JSON format:
{
  "caption": "Your generated caption here...",
  "hashtags": "#hashtag1 #hashtag2 #hashtag3",
  "imagePrompt": "Your detailed image generation prompt here..."
}
`;
};


export const GeminiService = {
  generateSocialMediaContent: async (formData: ContentFormData): Promise<GeneratedContent> => {
    if (!ai) throw new Error("Gemini AI client not initialized. Check API Key.");
    
    const prompt = constructPromptForTextModel(formData);
    
    try {
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: GEMINI_TEXT_MODEL,
        contents: prompt,
        config: {
          responseMimeType: "application/json", // Request JSON output
          // Omitting thinkingConfig for default (enabled) behavior
        },
      });

      let jsonStr = response.text.trim();
      // Remove markdown fences if present
      const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
      const match = jsonStr.match(fenceRegex);
      if (match && match[2]) {
        jsonStr = match[2].trim();
      }
      
      const parsedData = JSON.parse(jsonStr) as GeneratedContent;
      if (!parsedData.caption || !parsedData.hashtags || !parsedData.imagePrompt) {
        throw new Error("AI response missing one or more required fields (caption, hashtags, imagePrompt).");
      }
      return parsedData;

    } catch (error) {
      console.error("Error generating social media content:", error);
      if (error instanceof Error) {
        throw new Error(`Gemini API error for text generation: ${error.message}`);
      }
      throw new Error("Unknown Gemini API error for text generation.");
    }
  },

  generateImageFromPrompt: async (prompt: string): Promise<string> => {
    if (!ai) throw new Error("Gemini AI client not initialized. Check API Key.");

    try {
      const response = await ai.models.generateImages({
        model: GEMINI_IMAGE_MODEL,
        prompt: prompt,
        config: { 
            numberOfImages: 1, 
            outputMimeType: 'image/jpeg' // Or 'image/png'
        },
      });

      if (response.generatedImages && response.generatedImages.length > 0 && response.generatedImages[0].image?.imageBytes) {
        const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
        return `data:image/jpeg;base64,${base64ImageBytes}`;
      } else {
        throw new Error("No image data received from Gemini API.");
      }
    } catch (error) {
      console.error("Error generating image:", error);
       if (error instanceof Error) {
        throw new Error(`Gemini API error for image generation: ${error.message}`);
      }
      throw new Error("Unknown Gemini API error for image generation.");
    }
  },
};
