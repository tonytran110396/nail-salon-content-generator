
import React, { useState, useCallback } from 'react';
import { ContentFormData, GeneratedContent, ContentStyle, ToastType } from '../types';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Textarea } from '../components/ui/Textarea';
import { Label } from '../components/ui/Label';
import { Select } from '../components/ui/Select';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Spinner } from '../components/ui/Spinner';
import { IconCopy, IconDownload, IconImage } from '../components/icons';
import { POST_PURPOSES, CONTENT_STYLE_OPTIONS } from '../constants';
import PromotionalBanner from '../components/PromotionalBanner';
import { GeminiService } from '../services/geminiService';
import { useToast } from '../hooks/useToast';

const DashboardPage: React.FC = () => {
  const [formData, setFormData] = useState<ContentFormData>({
    postPurpose: POST_PURPOSES[0],
    topicKeywords: '',
    brandName: '',
    productService: '',
    contentStyleConcept: CONTENT_STYLE_OPTIONS[0],
    callToActionText: 'Book Now!',
    customerPersona: '',
    industry: 'Nail Care',
    customContentStyleConcept: '',
    specialOffer: '',
    address: '',
    phoneNumber: '',
    websiteLink: '',
  });

  const [generatedOutput, setGeneratedOutput] = useState<GeneratedContent | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null); // base64 string
  const [isGeneratingContent, setIsGeneratingContent] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const { addToast } = useToast();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text)
      .then(() => addToast(`${type} copied to clipboard!`, ToastType.SUCCESS))
      .catch(() => addToast(`Failed to copy ${type}.`, ToastType.ERROR));
  };

  const downloadImage = () => {
    if (!generatedImage) return;
    const link = document.createElement('a');
    link.href = generatedImage;
    link.download = `${formData.topicKeywords.replace(/\s+/g, '_') || 'nail_art'}_ai_image.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast('Image download started!', ToastType.SUCCESS);
  };
  
  const generateContentAndImage = useCallback(async () => {
    if (!formData.topicKeywords || !formData.brandName || !formData.productService || !formData.callToActionText) {
      addToast('Please fill in all required fields (Topic, Brand Name, Product/Service, Call To Action).', ToastType.ERROR);
      return;
    }
    if (formData.contentStyleConcept === ContentStyle.OTHER && !formData.customContentStyleConcept) {
        addToast('Please specify your custom content style when "Other" is selected.', ToastType.ERROR);
        return;
    }

    setIsGeneratingContent(true);
    setGeneratedOutput(null);
    setGeneratedImage(null);

    try {
      const contentResult = await GeminiService.generateSocialMediaContent(formData);
      setGeneratedOutput(contentResult);
      addToast('Content generated successfully!', ToastType.SUCCESS);
      
      // Now generate image
      if (contentResult.imagePrompt) {
        await generateImage(contentResult.imagePrompt);
      }
    } catch (error) {
      console.error("Error generating content:", error);
      addToast(`Failed to generate content: ${error instanceof Error ? error.message : 'Unknown error'}`, ToastType.ERROR);
      setGeneratedOutput(null);
    } finally {
      setIsGeneratingContent(false);
    }
  }, [formData, addToast]);


  const generateImage = useCallback(async (prompt?: string) => {
    const imagePromptToUse = prompt || generatedOutput?.imagePrompt;
    if (!imagePromptToUse) {
      addToast('No image prompt available to generate an image.', ToastType.WARNING);
      return;
    }
    setIsGeneratingImage(true);
    setGeneratedImage(null); // Clear previous image
    try {
      const imageUrl = await GeminiService.generateImageFromPrompt(imagePromptToUse);
      setGeneratedImage(imageUrl);
      addToast('Image generated successfully!', ToastType.SUCCESS);
    } catch (error) {
      console.error("Error generating image:", error);
      addToast(`Failed to generate image: ${error instanceof Error ? error.message : 'Unknown error'}`, ToastType.ERROR);
      setGeneratedImage(null);
    } finally {
      setIsGeneratingImage(false);
    }
  }, [generatedOutput, addToast]);


  const effectiveContentStyle = formData.contentStyleConcept === ContentStyle.OTHER
    ? formData.customContentStyleConcept
    : formData.contentStyleConcept;

  const isProcessing = isGeneratingContent || isGeneratingImage;

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-pink-700">Nail Salon Content Generator</CardTitle>
          <CardDescription>Fill in the details below to generate captivating social media content and a unique AI image for your nail salon.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={(e) => { e.preventDefault(); generateContentAndImage(); }} className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Column 1 */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="postPurpose">Post Purpose <span className="text-red-500">*</span></Label>
                <Select id="postPurpose" name="postPurpose" value={formData.postPurpose} onChange={handleInputChange} disabled={isProcessing}>
                  {POST_PURPOSES.map(purpose => <option key={purpose} value={purpose}>{purpose}</option>)}
                </Select>
              </div>
              <div>
                <Label htmlFor="topicKeywords">Topic / Keywords <span className="text-red-500">*</span></Label>
                <Input id="topicKeywords" name="topicKeywords" value={formData.topicKeywords} onChange={handleInputChange} placeholder="e.g., Spring floral nail art, luxury manicure" required disabled={isProcessing} />
              </div>
              <div>
                <Label htmlFor="brandName">Brand Name <span className="text-red-500">*</span></Label>
                <Input id="brandName" name="brandName" value={formData.brandName} onChange={handleInputChange} placeholder="e.g., The Nail Palace" required disabled={isProcessing} />
              </div>
              <div>
                <Label htmlFor="productService">Product / Service <span className="text-red-500">*</span></Label>
                <Input id="productService" name="productService" value={formData.productService} onChange={handleInputChange} placeholder="e.g., Gel extensions, Spa pedicure" required disabled={isProcessing} />
              </div>
               <div>
                <Label htmlFor="contentStyleConcept">Content Style & Concept <span className="text-red-500">*</span></Label>
                <Select id="contentStyleConcept" name="contentStyleConcept" value={formData.contentStyleConcept} onChange={handleInputChange} disabled={isProcessing}>
                  {CONTENT_STYLE_OPTIONS.map(style => <option key={style} value={style}>{style}</option>)}
                </Select>
              </div>
              {formData.contentStyleConcept === ContentStyle.OTHER && (
                <div>
                  <Label htmlFor="customContentStyleConcept">Specify Custom Style <span className="text-red-500">*</span></Label>
                  <Input id="customContentStyleConcept" name="customContentStyleConcept" value={formData.customContentStyleConcept || ''} onChange={handleInputChange} placeholder="e.g., Humorous and witty" required={formData.contentStyleConcept === ContentStyle.OTHER} disabled={isProcessing} />
                </div>
              )}
            </div>

            {/* Column 2 */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="callToActionText">Call To Action Text <span className="text-red-500">*</span></Label>
                <Input id="callToActionText" name="callToActionText" value={formData.callToActionText} onChange={handleInputChange} placeholder="e.g., Book Now, DM to book" required disabled={isProcessing} />
              </div>
              <div>
                <Label htmlFor="customerPersona">Customer Persona (Optional)</Label>
                <Input id="customerPersona" name="customerPersona" value={formData.customerPersona || ''} onChange={handleInputChange} placeholder="e.g., Young professionals, busy moms" disabled={isProcessing} />
              </div>
              <div>
                <Label htmlFor="industry">Industry (Optional)</Label>
                <Input id="industry" name="industry" value={formData.industry || ''} onChange={handleInputChange} placeholder="e.g., Nail Care, Beauty Salon" disabled={isProcessing} />
              </div>
              <div>
                <Label htmlFor="specialOffer">Special Offer (Optional)</Label>
                <Input id="specialOffer" name="specialOffer" value={formData.specialOffer || ''} onChange={handleInputChange} placeholder="e.g., 20% off first visit" disabled={isProcessing} />
              </div>
              <div>
                <Label htmlFor="address">Address (Optional)</Label>
                <Input id="address" name="address" value={formData.address || ''} onChange={handleInputChange} placeholder="e.g., 123 Main St, Anytown" disabled={isProcessing} />
              </div>
              <div>
                <Label htmlFor="phoneNumber">Phone Number (Optional)</Label>
                <Input id="phoneNumber" name="phoneNumber" type="tel" value={formData.phoneNumber || ''} onChange={handleInputChange} placeholder="e.g., (555) 123-4567" disabled={isProcessing} />
              </div>
              <div>
                <Label htmlFor="websiteLink">Website Link (Optional)</Label>
                <Input id="websiteLink" name="websiteLink" type="url" value={formData.websiteLink || ''} onChange={handleInputChange} placeholder="e.g., https://yournailsalon.com" disabled={isProcessing} />
              </div>
            </div>
            
            {/* Submit Button - Full Width */}
            <div className="md:col-span-2 mt-4">
              <Button type="submit" size="lg" className="w-full" disabled={isProcessing}>
                {isProcessing ? <Spinner size="small" className="mr-2"/> : null}
                {isGeneratingContent ? 'Generating Content...' : isGeneratingImage ? 'Generating Image...' : 'Generate Content & Image'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {(isGeneratingContent || generatedOutput) && (
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-pink-700">Generated Output</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {isGeneratingContent && !generatedOutput && (
              <div className="flex items-center justify-center py-8">
                <Spinner size="large" />
                <p className="ml-4 text-gray-600">Generating content, please wait...</p>
              </div>
            )}
            {generatedOutput && (
              <>
                <div>
                  <Label className="text-lg font-semibold">Caption</Label>
                  <div className="relative mt-1 p-3 border rounded-md bg-gray-50 whitespace-pre-wrap">
                    {generatedOutput.caption}
                    <Button variant="ghost" size="icon" className="absolute top-1 right-1 text-gray-500 hover:text-pink-600" onClick={() => copyToClipboard(generatedOutput.caption, 'Caption')}>
                      <IconCopy className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
                <div>
                  <Label className="text-lg font-semibold">Hashtags</Label>
                  <div className="relative mt-1 p-3 border rounded-md bg-gray-50">
                    <div className="flex flex-wrap gap-2">
                      {generatedOutput.hashtags.split(' ').map((tag, index) => tag.startsWith('#') && <Badge key={index} variant="secondary">{tag}</Badge>)}
                    </div>
                    <Button variant="ghost" size="icon" className="absolute top-1 right-1 text-gray-500 hover:text-pink-600" onClick={() => copyToClipboard(generatedOutput.hashtags, 'Hashtags')}>
                      <IconCopy className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
                <div>
                  <Label className="text-lg font-semibold">Image Prompt</Label>
                  <div className="relative mt-1 p-3 border rounded-md bg-gray-50">
                    <p className="text-sm text-gray-700">{generatedOutput.imagePrompt}</p>
                    <Button variant="ghost" size="icon" className="absolute top-1 right-1 text-gray-500 hover:text-pink-600" onClick={() => copyToClipboard(generatedOutput.imagePrompt, 'Image Prompt')}>
                      <IconCopy className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
                <div>
                  <Label className="text-lg font-semibold">AI-Generated Image</Label>
                  <div className="mt-2 p-4 border rounded-md bg-gray-50 min-h-[200px] flex flex-col items-center justify-center">
                    {isGeneratingImage && (
                       <div className="flex flex-col items-center justify-center py-8">
                         <Spinner size="large" />
                         <p className="ml-4 text-gray-600">Generating image...</p>
                       </div>
                    )}
                    {!isGeneratingImage && generatedImage && (
                      <img src={generatedImage} alt="AI Generated Nail Art" className="max-w-full max-h-96 rounded-md shadow-md mb-4"/>
                    )}
                    {!isGeneratingImage && !generatedImage && (
                      <div className="text-center text-gray-500 py-8">
                        <IconImage className="w-16 h-16 mx-auto mb-2" />
                        <p>Image will appear here once generated.</p>
                        {generatedOutput.imagePrompt && <p className="text-xs mt-1">Ready to generate using the prompt above.</p>}
                      </div>
                    )}
                     <div className="flex space-x-2 mt-4">
                        <Button onClick={() => generateImage()} disabled={isGeneratingImage || !generatedOutput?.imagePrompt || isGeneratingContent} variant="secondary">
                          {isGeneratingImage && <Spinner size="small" className="mr-2"/>}
                          {generatedImage ? 'Regenerate Image' : 'Generate Image'}
                        </Button>
                        {generatedImage && (
                           <Button onClick={downloadImage} disabled={isGeneratingImage} variant="outline">
                            <IconDownload className="w-4 h-4 mr-2"/> Download Image
                          </Button>
                        )}
                      </div>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      )}
      <PromotionalBanner />
    </div>
  );
};

export default DashboardPage;
